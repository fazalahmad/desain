// window.onload = function(){
//   document.getElementById('demo').innerHTML = "hello";
// }

/*var x = "Hello";
var y = 12;
var nama = "Fazal";
document.write("<br>",x + y,"<br>");
document.write(`hello ${nama}`);*/

// //object
// var obj = {
//   nama : "Fazal";,
//   kota : "Bandung";
// }
//
// //array
// var ary = [1, 2, 3]
//
// //menampung fungsi
// var nama = function(){
//   return "fazal";
// }
//
// document.write(nama());

// for (var i = 0; i <= 10; i++) {
//   if(i % 2 == 1){
//     document.write(i);
//   }
// }

// #demo {
//   //property
// }

/*document.querySelectorAll("button")[0].onclick = function(){
  window.alert("Hello");
} atau
function myAlert(){
  window.alert("hello");
} */

// document.querySelectorAll("button")[0].addEventListener("click", function(){
//   window.alert("Hello Fazal");
// })
$( "button:first-child" ).click(function() {
  alert( "Hello 1" );
});

$( "button:nth-child(2)" ).click(function() {
  alert( "Hello 2" );
});

$( "button:nth-child(3)" ).click(function() {
  alert( "Hello 3" );
});
